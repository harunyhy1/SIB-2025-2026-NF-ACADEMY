#!/usr/bin/env python3
"""
aes_file_crypto.py
==================
Alur lengkap enkripsi-dekripsi file teks dengan AES-256-GCM
menggunakan library `cryptography`.

Alur:
    1. Generate AES-256 key  -> disimpan ke file terpisah (secret.key)
    2. Enkripsi plaintext    -> hasil disimpan sebagai file .enc
    3. Dekripsi file .enc    -> hasil disimpan sebagai file teks baru
    4. Verifikasi            -> hasil dekripsi harus identik dengan file asli

Cara pakai:
    python aes_file_crypto.py                 # jalankan seluruh alur (demo)
    python aes_file_crypto.py --input pesan.txt

Mode enkripsi: AES-256-GCM (authenticated encryption).
    - Selain merahasiakan isi, GCM juga mendeteksi jika file .enc diubah
      (tag autentikasi). Jika file rusak/dimodifikasi atau key salah,
      dekripsi akan GAGAL dengan error, bukan menghasilkan data sampah.
    - Format file .enc:  [ nonce 12 byte ][ ciphertext + tag 16 byte ]
"""

import argparse
import hashlib
import os
import sys

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

# ---------------------------------------------------------------------------
# Konfigurasi nama file
# ---------------------------------------------------------------------------
KEY_FILE = "secret.key"           # tempat key disimpan (JANGAN di-commit ke Git!)
DEFAULT_PLAINTEXT = "plaintext.txt"
ENCRYPTED_FILE = "plaintext.txt.enc"
DECRYPTED_FILE = "decrypted.txt"

KEY_SIZE_BYTES = 32               # 32 byte = 256 bit -> AES-256
NONCE_SIZE_BYTES = 12             # ukuran nonce standar untuk GCM


# ---------------------------------------------------------------------------
# 1. GENERATE KEY
# ---------------------------------------------------------------------------
def generate_key(key_path: str = KEY_FILE) -> bytes:
    """Buat key AES-256 acak dan simpan ke file terpisah (bukan hardcode).

    -----------------------------------------------------------------------
    DOKUMENTASI KEAMANAN KEY
    -----------------------------------------------------------------------
    [Di mana key disimpan?]
        Di file `secret.key` pada folder kerja script ini. Permission file
        dibatasi ke 0600 (hanya pemilik yang bisa baca/tulis) di Linux/macOS.
        Ini HANYA cocok untuk belajar/tugas. Key tidak ditulis di dalam
        source code, jadi tidak ikut bocor jika kode dibagikan.

    [Risiko jika key bocor]
        - Siapa pun yang memegang key dapat mendekripsi SEMUA file yang
          dienkripsi dengan key tersebut (kerahasiaan hilang total).
        - Penyerang juga bisa membuat file .enc palsu yang lolos verifikasi
          (integritas hilang), karena GCM bergantung pada kerahasiaan key.
        - Enkripsi yang kuat tidak ada artinya jika key-nya bocor: seluruh
          keamanan sistem bergantung pada kerahasiaan key.
        - Jika key hilang, data terenkripsi TIDAK bisa dipulihkan.

    [Cara aman di production]
        - Simpan key di Secret Manager / KMS / HSM, misalnya AWS KMS,
          Google Cloud KMS, Azure Key Vault, atau HashiCorp Vault.
        - Gunakan envelope encryption: data dienkripsi dengan Data Key,
          dan Data Key itu dienkripsi lagi dengan Master Key di KMS.
        - Jangan commit key ke Git (tambahkan *.key ke .gitignore), jangan
          kirim lewat chat/email, dan jangan tulis ke log.
        - Terapkan akses minimum (least privilege) dan audit log akses key.
        - Lakukan rotasi key berkala dan siapkan prosedur backup/recovery.
        - Jika memakai environment variable, itu pun hanya langkah
          menengah; secret manager tetap lebih baik.
    -----------------------------------------------------------------------
    """
    key = AESGCM.generate_key(bit_length=256)  # 32 byte dari CSPRNG OS

    # Tulis dengan permission 0600 sejak file dibuat (tidak sempat terbaca
    # user lain). 'xb' = gagal jika file sudah ada, agar key lama tidak
    # tertimpa tanpa sengaja.
    fd = os.open(key_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(key)

    print(f"[1] Key AES-256 dibuat dan disimpan di: {key_path}")
    return key


def load_key(key_path: str = KEY_FILE) -> bytes:
    """Baca key dari file dan pastikan ukurannya benar (32 byte)."""
    with open(key_path, "rb") as f:
        key = f.read()
    if len(key) != KEY_SIZE_BYTES:
        raise ValueError(
            f"Ukuran key tidak valid: {len(key)} byte (seharusnya {KEY_SIZE_BYTES})."
        )
    return key


# ---------------------------------------------------------------------------
# 2. ENKRIPSI FILE
# ---------------------------------------------------------------------------
def encrypt_file(input_path: str, output_path: str, key: bytes) -> None:
    """Baca plaintext, enkripsi dengan AES-256-GCM, simpan sebagai .enc."""
    with open(input_path, "rb") as f:
        plaintext = f.read()

    # Nonce WAJIB unik untuk setiap enkripsi dengan key yang sama.
    # Memakai ulang nonce+key pada GCM merusak keamanan secara fatal.
    nonce = os.urandom(NONCE_SIZE_BYTES)

    aesgcm = AESGCM(key)
    ciphertext = aesgcm.encrypt(nonce, plaintext, None)  # tag ikut di akhir

    # Nonce tidak rahasia, jadi disimpan di depan ciphertext.
    with open(output_path, "wb") as f:
        f.write(nonce + ciphertext)

    print(f"[2] '{input_path}' berhasil dienkripsi -> '{output_path}'")


# ---------------------------------------------------------------------------
# 3. DEKRIPSI FILE
# ---------------------------------------------------------------------------
def decrypt_file(input_path: str, output_path: str, key: bytes) -> None:
    """Baca file .enc, dekripsi dengan key yang sama, simpan sebagai plaintext."""
    with open(input_path, "rb") as f:
        data = f.read()

    if len(data) < NONCE_SIZE_BYTES + 16:
        raise ValueError("File .enc tidak valid (terlalu pendek).")

    nonce, ciphertext = data[:NONCE_SIZE_BYTES], data[NONCE_SIZE_BYTES:]

    try:
        plaintext = AESGCM(key).decrypt(nonce, ciphertext, None)
    except InvalidTag:
        # Terjadi jika key salah ATAU file .enc diubah/rusak.
        raise ValueError(
            "Dekripsi gagal: key salah atau file .enc telah dimodifikasi."
        ) from None

    with open(output_path, "wb") as f:
        f.write(plaintext)

    print(f"[3] '{input_path}' berhasil didekripsi -> '{output_path}'")


# ---------------------------------------------------------------------------
# 4. VERIFIKASI
# ---------------------------------------------------------------------------
def sha256_of_file(path: str) -> str:
    """Hitung hash SHA-256 sebuah file."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def verify_files(original_path: str, decrypted_path: str) -> bool:
    """Pastikan hasil dekripsi identik (byte per byte) dengan file asli."""
    with open(original_path, "rb") as f1, open(decrypted_path, "rb") as f2:
        identical = f1.read() == f2.read()

    print(f"[4] SHA-256 asli      : {sha256_of_file(original_path)}")
    print(f"    SHA-256 dekripsi  : {sha256_of_file(decrypted_path)}")
    if identical:
        print("    HASIL: BERHASIL - file hasil dekripsi identik dengan file asli.")
    else:
        print("    HASIL: GAGAL - file hasil dekripsi BERBEDA dari file asli!")
    return identical


# ---------------------------------------------------------------------------
# MAIN
# ---------------------------------------------------------------------------
def create_sample_plaintext(path: str) -> None:
    """Buat file contoh jika file plaintext belum ada."""
    sample = (
        "Ini adalah contoh file plaintext untuk tugas enkripsi AES-256.\n"
        "Karakter khusus & unicode: áéíóú 你好 😀\n"
        "Baris ketiga untuk memastikan newline tetap utuh.\n"
    )
    with open(path, "w", encoding="utf-8") as f:
        f.write(sample)
    print(f"[0] File contoh dibuat: {path}")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Demo enkripsi-dekripsi file teks dengan AES-256-GCM."
    )
    parser.add_argument(
        "--input",
        default=DEFAULT_PLAINTEXT,
        help=f"File plaintext yang dienkripsi (default: {DEFAULT_PLAINTEXT}).",
    )
    args = parser.parse_args()

    # Siapkan file plaintext
    if not os.path.exists(args.input):
        create_sample_plaintext(args.input)

    # 1. Generate key baru, atau pakai key yang sudah ada
    if os.path.exists(KEY_FILE):
        print(f"[1] Memakai key yang sudah ada: {KEY_FILE}")
        key = load_key(KEY_FILE)
    else:
        key = generate_key(KEY_FILE)

    enc_path = args.input + ".enc"

    # 2. Enkripsi
    encrypt_file(args.input, enc_path, key)

    # 3. Dekripsi (key dibaca ulang dari file untuk membuktikan key tersimpan benar)
    decrypt_file(enc_path, DECRYPTED_FILE, load_key(KEY_FILE))

    # 4. Verifikasi
    ok = verify_files(args.input, DECRYPTED_FILE)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())

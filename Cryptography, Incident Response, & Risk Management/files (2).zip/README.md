# Enkripsi & Dekripsi File dengan AES-256-GCM

Script Python yang mencakup seluruh alur enkripsi-dekripsi file teks
menggunakan library [`cryptography`](https://cryptography.io).

## Isi Pengumpulan

| File | Keterangan |
|------|------------|
| `aes_file_crypto.py` | Script utama |
| `README.md` | Dokumen ini |

## Alur Program

1. **Generate key**: membuat key AES-256 (32 byte acak) dan menyimpannya ke file terpisah `secret.key` (tidak di-hardcode).
2. **Enkripsi**: membaca `plaintext.txt`, mengenkripsi dengan AES-256-GCM, menyimpan hasilnya ke `plaintext.txt.enc`.
3. **Dekripsi**: membaca `plaintext.txt.enc`, mendekripsi dengan key dari `secret.key`, menyimpan hasilnya ke `decrypted.txt`.
4. **Verifikasi**: membandingkan file asli dan hasil dekripsi (byte per byte + hash SHA-256) dan mencetak hasil BERHASIL/GAGAL.

## Prasyarat

- Python 3.8 atau lebih baru
- Library `cryptography`

```bash
pip install cryptography
```

## Cara Menjalankan

```bash
# Jalankan seluruh alur. File plaintext contoh dibuat otomatis jika belum ada
python aes_file_crypto.py

# Atau enkripsi file teks milik sendiri
python aes_file_crypto.py --input catatan.txt
```

### Contoh Output

```
[0] File contoh dibuat: plaintext.txt
[1] Key AES-256 dibuat dan disimpan di: secret.key
[2] 'plaintext.txt' berhasil dienkripsi -> 'plaintext.txt.enc'
[3] 'plaintext.txt.enc' berhasil didekripsi -> 'decrypted.txt'
[4] SHA-256 asli      : 304d25bf...
    SHA-256 dekripsi  : 304d25bf...
    HASIL: BERHASIL - file hasil dekripsi identik dengan file asli.
```

### File yang Dihasilkan

| File | Isi |
|------|-----|
| `secret.key` | Key AES-256 (32 byte, biner). **Rahasia!** |
| `plaintext.txt.enc` | Hasil enkripsi: `nonce (12 byte) + ciphertext + tag (16 byte)` |
| `decrypted.txt` | Hasil dekripsi, identik dengan file asli |

Jika `secret.key` sudah ada, script memakainya kembali. Hapus file tersebut jika ingin membuat key baru. Ingat, file `.enc` lama tidak bisa didekripsi dengan key baru.

## Penjelasan Teknis

- **Algoritma**: AES-256 mode **GCM** (authenticated encryption). Selain menjaga kerahasiaan, GCM mendeteksi jika file `.enc` diubah. Key yang salah atau file yang dimodifikasi menyebabkan dekripsi gagal dengan pesan error, bukan menghasilkan data acak.
- **Nonce**: 12 byte acak dari `os.urandom`, dibuat baru di setiap enkripsi dan disimpan di awal file `.enc` (nonce tidak rahasia, tetapi tidak boleh dipakai ulang dengan key yang sama).
- **Key**: dibuat oleh `AESGCM.generate_key(bit_length=256)` dari generator acak aman milik OS, dan disimpan dengan permission `0600` (Linux/macOS).

## Dokumentasi Keamanan Key

**Di mana key disimpan?**
Di file `secret.key` pada folder kerja. Ini hanya cocok untuk belajar atau tugas. Key tidak ada di dalam kode sumber.

**Risiko jika key bocor**
- Siapa pun yang memegang key bisa mendekripsi semua file yang dienkripsi dengannya (kerahasiaan hilang).
- Penyerang dapat membuat file `.enc` palsu yang lolos verifikasi (integritas hilang).
- Seluruh keamanan bergantung pada kerahasiaan key, sehingga algoritma sekuat apa pun tidak membantu jika key bocor.
- Jika key hilang, data tidak bisa dipulihkan.

**Cara aman di production**
- Simpan key di Secret Manager / KMS / HSM (AWS KMS, Google Cloud KMS, Azure Key Vault, HashiCorp Vault).
- Gunakan *envelope encryption*: data dienkripsi dengan data key, data key dienkripsi dengan master key di KMS.
- Jangan commit key ke Git (tambahkan `*.key` ke `.gitignore`), jangan kirim lewat chat/email, jangan tulis ke log.
- Terapkan akses minimum (*least privilege*) dan audit log untuk setiap akses key.
- Rotasi key secara berkala dan siapkan backup serta prosedur pemulihan.

## Catatan

Script membaca seluruh file ke memori, jadi cocok untuk file teks berukuran kecil sampai menengah. Untuk file sangat besar, gunakan enkripsi per potongan (*chunked*) atau library seperti `age`/Fernet streaming.
